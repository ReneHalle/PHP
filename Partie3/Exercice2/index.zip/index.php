    <?php
    // Création d'un tableau mois avec janvier comme valeur 0
    $months = array('janvier','février','mars','avril','mai','juin','juillet','août','septembre','octobre','novembre','décembre');
    ?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exercice 2</title>
</head>
<body>
    <p><?= $months[5]; ?></p>

    <a href="http://php-partie3/"><button>Retour au menu</button></a>
</body>
</html>